# Course repository for Deep Learning Foundations and Applications(AI61002)
[Link](http://www.facweb.iitkgp.ac.in/~debdoot/courses/AI61002/Spr2019/) to course website.
